import react from  'react'

function navbar(){
  return( 
  <>
 <h1>helo</h1>
  </>
  )
}
export default Navbar; 