import React from 'react'
import Carousel from 'react-bootstrap/Carousel'

export const Slider = () => {
    return (
        <div>
            <h2>Slider</h2>
        </div>
    )
}

export default Slider;