import React from 'react'

const Contact = () => {
    return (
        <div>
            This is contact page rupali
        </div>
    )
}

export default Contact
